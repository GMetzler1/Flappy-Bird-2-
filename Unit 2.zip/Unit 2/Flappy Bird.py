import pygame
pygame.init()

window_size = (800, 600)
pygame.display.set_caption('Graydon Metzler Flappy Bird')
screen = pygame.display.set_mode(window_size)

# Load an image
bird_image = pygame.image.load('C:/Users/grayd/Desktop/Unit 2/Flappy Bird Basics/bird1.png') # Make sure to have an image named 'bird1.png' in the same folder

# Scale the image
bird_image = pygame.transform.scale(bird_image, (65, 50))

# *** NEW CODE ***
bird_x = 50
bird_y = 50

# A Simple Game Loop
running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
 
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                print("Spacebar pressed")


    screen.fill((255, 255, 255))  # Fill the screen with white color

    pygame.draw.rect(screen, (255, 0, 0), (50, 50, 50, 50)) # window, color, position to draw the rectangle
 
 # *** NEW CODE ***
    screen.blit(bird_image, (bird_x, bird_y)) # this will display our bird at the variable position bird_x and bird_y
    
    pygame.display.flip()  # Update the display

    pygame.time.delay(30)

pygame.quit()